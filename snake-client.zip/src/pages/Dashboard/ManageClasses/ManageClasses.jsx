import React from 'react';
import useAxiosSecure from '../../../hooks/useAxiosSecure';
import { useQuery } from '@tanstack/react-query';

const ManageClasses = () => {
    const [axiosSecure] = useAxiosSecure()
    // const {data} = useQuery(['classes', async() => {
    //     const res = await axiosSecure.get('/classes/instructorClass');
    //     return res.data
    // }])
    const { data: courses = [] } = useQuery({
        queryKey: ["classes"],
        queryFn: async () => {
          //    const res = await fetch(`http://localhost:5000/classes/instructor?email=${user?.email}`)
          const res = await axiosSecure.get('/classes/instructorClass');
    
          return res.data;
        },
      });
    console.log(courses)
    return (
        <div>
            
        </div>
    );
};

export default ManageClasses;